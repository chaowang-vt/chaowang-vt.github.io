
int retVal[1];
int* compute(int P0, int P1, int P2, int P3, int P4, int P5, int P6, int P7, int P8) {
	int K0, K1, K2, K3, K4, K5, K6, K7, K8;
	int tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8;
	int sum0, sum1, sum2, sum3, sum4, sum5, sum6, sum7;
	int normalize;
	int center;

	int P0s, P1s, P2s, P3s, P4s, P5s, P6s, P7s, P8s;

	P0s = P0 << 3;
	P1s = P1 << 3;
	P2s = P2 << 3;
	P3s = P3 << 3;
	P4s = P4 << 3;
	P5s = P5 << 3;
	P6s = P6 << 3;
	P7s = P7 << 3;
	P8s = P8 << 3;





	K0 = 0;
	K1 = -8;
	K2 = 0;
	K3 = 8;
	K4 = 16;
	K5 = 8;
	K6 = 0;
	K7 = -8;
	K8 = -16;

	tmp0 = (K0*P0s)>>3;
	tmp1 = (K1*P1s)>>3;
	tmp2 = (K2*P2s)>>3;
	tmp3 = (K3*P3s)>>3;
	tmp4 = (K4*P4s)>>3;
	tmp5 = (K5*P5s)>>3;
	tmp6 = (K6*P6s)>>3;
	tmp7 = (K7*P7s)>>3;
	tmp8 = (K8*P8s)>>3;

	sum0 = tmp0 + tmp1;
	sum1 = sum0 + tmp2;
	sum2 = sum1 + tmp3;
	sum3 = sum2 + tmp4;
	sum4 = sum3 + tmp5;
	sum5 = sum4 + tmp6;
	sum6 = sum5 + tmp7;
	sum7 = sum6 + tmp8;

	normalize = (sum7>>3);
	center = normalize + 1020;


        {
	retVal[0] = center;
        }

        return retVal;
} 
