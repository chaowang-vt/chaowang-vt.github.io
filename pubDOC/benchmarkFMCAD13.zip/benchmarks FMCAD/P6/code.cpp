
int retVal[1];
int* compute(int P3, int P7, int P8, int P9, int P11, int P12, int P13, int P14, int P15, int P17, int P18, int P19, int P23) {


	int P1s, P2s, P4s, P5s, P6s, P10s;
	int P16s, P20s, P21s, P22s, P24s, P25s;
	int K1, K2, K3, K4, K5;
	int K6, K7, K8, K9, K10;
	int K11, K12, K13, K14, K15;
	int K16, K17, K18, K19, K20;
	int K21, K22, K23, K24, K25;
	int tmp1, tmp2, tmp3, tmp4, tmp5;
	int tmp6, tmp7, tmp8, tmp9, tmp10;
	int tmp11, tmp12, tmp13, tmp14, tmp15;
	int tmp16, tmp17, tmp18, tmp19, tmp20;
	int tmp21, tmp22, tmp23, tmp24, tmp25;
	int sum1, sum2, sum3, sum4, sum5;
	int sum6, sum7, sum8, sum9, sum10;
	int sum11, sum12, sum13, sum14, sum15;
	int sum16, sum17, sum18, sum19, sum20;
	int sum21, sum22, sum23, sum24, sum25;
	int normalize;
	int center;


	int P3s, P7s, P8s, P9s, P11s, P12s, P13s, P14s, P15s, P17s, P18s, P19s, P23s;

	P3s = P3 << 4;
	P7s = P7 << 4;
	P8s = P8 << 4;
	P9s = P9 << 4;
	P11s = P11 << 4;
	P12s = P12 << 4;
	P13s = P13 << 4;
	P14s = P14 << 4;
	P15s = P15 << 4;
	P17s = P17 << 4;
	P18s = P18 << 4;
	P19s = P19 << 4;
	P23s = P23 << 4;

	P1s = 0;
	P2s = 0;
	P4s = 0;
	P5s = 0;
	P6s = 0;
	P10s = 0;
	P16s = 0;
	P20s = 0;
	P21s = 0;
	P22s = 0;
	P24s = 0;
	P25s = 0;

	K1 = 0;
	K2 = 0;
	K3 = -16;
	K4 = 0;
	K5 = 0;

	K6 = 0;
	K7 = -16;
	K8 = -32;
	K9 = -16;
	K10 = 0;

	K11 = -16;
	K12 = -32;
	K13 = 256;
	K14 = -32;
	K15 = -16;

	K16 = 0;
	K17 = -16;
	K18 = -32;
	K19 = -16;
	K20 = 0;

	K21 = 0;
	K22 = 0;
	K23 = -16;
	K24 = 0;
	K25 = 0;



	tmp1 = (K1*P1s)>>4;
	tmp2 = (K2*P2s)>>4;
	tmp3 = (K3*P3s)>>4;
	tmp4 = (K4*P4s)>>4;
	tmp5 = (K5*P5s)>>4;

	tmp6 = (K6*P6s)>>4;
	tmp7 = (K7*P7s)>>4;
	tmp8 = (K8*P8s)>>4;
	tmp9 = (K9*P9s)>>4;
	tmp10 = (K10*P10s)>>4;

	tmp11 = (K11*P11s)>>4;
	tmp12 = (K12*P12s)>>4;
	tmp13 = (K13*P13s)>>4;
	tmp14 = (K14*P14s)>>4;
	tmp15 = (K15*P15s)>>4;

	tmp16 = (K16*P16s)>>4;
	tmp17 = (K17*P17s)>>4;
	tmp18 = (K18*P18s)>>4;
	tmp19 = (K19*P19s)>>4;
	tmp20 = (K20*P20s)>>4;

	tmp21 = (K21*P21s)>>4;
	tmp22 = (K22*P22s)>>4;
	tmp23 = (K23*P23s)>>4;
	tmp24 = (K24*P24s)>>4;
	tmp25 = (K25*P25s)>>4;

	sum1 = tmp1 + tmp2;
	sum2 = sum1 + tmp3;
	sum3 = sum2 + tmp4;
	sum4 = sum3 + tmp5;
	sum5 = sum4 + tmp6;
	sum6 = sum5 + tmp7;
	sum7 = sum6 + tmp8;
	sum8 = sum7 + tmp9;
	sum9 = sum8 + tmp10;
	sum10 = sum9 + tmp11;
	sum11 = sum10 + tmp12;
	sum12 = sum11 + tmp13;
	sum13 = sum12 + tmp14;
	sum14 = sum13 + tmp15;
	sum15 = sum14 + tmp16;
	sum16 = sum15 + tmp17;
	sum17 = sum16 + tmp18;
	sum18 = sum17 + tmp19;
	sum19 = sum18 + tmp20;
	sum20 = sum19 + tmp21;
	sum21 = sum20 + tmp22;
	sum22 = sum21 + tmp23;
	sum23 = sum22 + tmp24;
	sum24 = sum23 + tmp25;


	normalize = (sum24>>4);

	center = (normalize>>1) + 2040;


	{
	retVal[0] = center;
	}

	return retVal;
} 
