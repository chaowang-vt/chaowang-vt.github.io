
int retVal[1];
int* compute(int Xk0, int Xk1, int Xk2)
{
int Gain1; 
int Gain2; 
int u1;
int tmp0, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11;
int OutputMatrixC_Gain0, OutputMatrixC_Gain1, OutputMatrixC_Gain2, OutputMatrixC_Gain3, OutputMatrixC_Gain4, OutputMatrixC_Gain5, OutputMatrixC_Gain6, OutputMatrixC_Gain7, OutputMatrixC_Gain8;
int CXk0, CXk1, CXk2; 

Gain2 = 310689525;
OutputMatrixC_Gain0 = -213320228;
OutputMatrixC_Gain1 = -174408305;
OutputMatrixC_Gain2 =   11744059;
OutputMatrixC_Gain3 = -189351305;
OutputMatrixC_Gain4 = -209180667;
OutputMatrixC_Gain5 =   49980525;
OutputMatrixC_Gain6 = -213264478;
OutputMatrixC_Gain7 = -199648872;
OutputMatrixC_Gain8 =    1911452;

tmp0 = (OutputMatrixC_Gain0 * Xk0 ) >> 30;
tmp1 = (OutputMatrixC_Gain3 * Xk1 ) >> 30;
tmp2 = (OutputMatrixC_Gain6 * Xk2 ) >> 30;
CXk0 = (tmp0 + tmp1) + tmp2;

tmp3 = (OutputMatrixC_Gain1 * Xk0 ) >> 30;
tmp4 = (OutputMatrixC_Gain4 * Xk1 ) >> 30;
tmp5 = (OutputMatrixC_Gain7 * Xk2 ) >> 30;
CXk1 = (tmp3 + tmp4) + tmp5;

tmp6 = (OutputMatrixC_Gain2 * Xk0 ) >> 30;
tmp7 = (OutputMatrixC_Gain5 * Xk1 ) >> 30;
tmp8 = (OutputMatrixC_Gain8 * Xk2 ) >> 30;
CXk2 = (tmp6 + tmp7) + tmp8;

tmp9 =  (-2132457011 * CXk0 ) >> 31;
tmp10 = (-1908245830 * CXk1 ) >> 31;
tmp11 = (-2087544933 * CXk2 ) >> 31;
Gain1 = (tmp9 + tmp10) + tmp11;
u1 = (Gain1>>1) + Gain2;

{
retVal[0] = u1;
}

return retVal;
} 
