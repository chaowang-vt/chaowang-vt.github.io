
int retVal[1];
int* compute(int In1, int In2, int In3){


int Subtract; 
int Gain; 
int Gain2; 

int Out1; 

Subtract = In1 - In2;
Gain = (26542 * Subtract) >>15;
Gain2 = (16663 * In3) >>14;
Out1 = ((Gain<<1) - Gain2)>>1;


{
retVal[0] = Out1;
}

return retVal;
} 
