
int retVal[8];
int* compute(int Din0, int Din1, int Din2, int Din3, int Din4, int Din5, int Din6, int Din7){

int dout0, dout1, dout2, dout3, dout4, dout5, dout6, dout7;
int Din0s;
int Din1s;
int Din2s;
int Din3s;
int Din4s;
int Din5s;
int Din6s;
int Din7s;

int Coeff00, Coeff01, Coeff02, Coeff03;
int dout0tmp0, dout0tmp1, dout0tmp2, dout0tmp3;
int Coeff10, Coeff11, Coeff12, Coeff13;
int dout1tmp0, dout1tmp1, dout1tmp2, dout1tmp3;
int Coeff20, Coeff21, Coeff22, Coeff23;
int dout2tmp0, dout2tmp1, dout2tmp2, dout2tmp3;
int Coeff30, Coeff31, Coeff32, Coeff33;
int dout3tmp0, dout3tmp1, dout3tmp2, dout3tmp3;

int Coeff40, Coeff41, Coeff42, Coeff43;
int dout4tmp0, dout4tmp1, dout4tmp2, dout4tmp3;
int Coeff50, Coeff51, Coeff52, Coeff53;
int dout5tmp0, dout5tmp1, dout5tmp2, dout5tmp3;
int Coeff60, Coeff61, Coeff62, Coeff63;
int dout6tmp0, dout6tmp1, dout6tmp2, dout6tmp3;
int Coeff70, Coeff71, Coeff72, Coeff73;
int dout7tmp0, dout7tmp1, dout7tmp2, dout7tmp3;

int y0, y1, y2, y3, y4, y5, y6, y7;


Coeff00 = 255;   
Coeff01 = 255;
Coeff02 = 255;
Coeff03 = 255;

Coeff10 = 250;   
Coeff11 = 212;
Coeff12 = 142;
Coeff13 = 50;

Coeff20 = 236;   
Coeff21 = 98;
Coeff22 = -98;
Coeff23 = -236;

Coeff30 = 212;   
Coeff31 = -50;
Coeff32 = -250;
Coeff33 = -142;

Coeff40 = 180;   
Coeff41 = -180;
Coeff42 = -180;
Coeff43 = 180;

Coeff50 = 142;   
Coeff51 = -250;
Coeff52 = 50;
Coeff53 = 212;

Coeff60 = 98;   
Coeff61 = -236;
Coeff62 = 236;
Coeff63 = -98;

Coeff70 = 50;   
Coeff71 = -142;
Coeff72 = 212;
Coeff73 = -250;

 Din0s = (Din0 << 8);
 Din1s = (Din1 << 8);
 Din2s = (Din2 << 8);
 Din3s = (Din3 << 8);
 Din4s = (Din4 << 8);
 Din5s = (Din5 << 8);
 Din6s = (Din6 << 8);
 Din7s = (Din7 << 8);



dout0 = 0 ;
dout0tmp0 =  dout0 +     ((Coeff00 * Din0s)>>8);
dout0tmp1 =  dout0tmp0 + ((Coeff01 * Din1s)>>8);
dout0tmp2 =  dout0tmp1 + ((Coeff02 * Din2s)>>8);
dout0tmp3 =  dout0tmp2 + ((Coeff03 * Din3s)>>8);
dout1 = 0;
dout1tmp0 =  dout1 +     ((Coeff10 * Din0s)>>8);
dout1tmp1 =  dout1tmp0 + ((Coeff11 * Din1s)>>8);
dout1tmp2 =  dout1tmp1 + ((Coeff12 * Din2s)>>8);
dout1tmp3 =  dout1tmp2 + ((Coeff13 * Din3s)>>8);
dout2 = 0 ;
dout2tmp0 =  dout2 +      ((Coeff20 * Din0s)>>8);
dout2tmp1 =  dout2tmp0 + ((Coeff21 * Din1s)>>8);
dout2tmp2 =  dout2tmp1 + ((Coeff22 * Din2s)>>8);
dout2tmp3 =  dout2tmp2 + ((Coeff23 * Din3s)>>8);
dout3 = 0 ;
dout3tmp0 =  dout3 +      ((Coeff30 * Din0s)>>8);
dout3tmp1 =  dout3tmp0 + ((Coeff31 * Din1s)>>8);
dout3tmp2 =  dout3tmp1 + ((Coeff32 * Din2s)>>8);
dout3tmp3 =  dout3tmp2 + ((Coeff33 * Din3s)>>8);

dout4 = 0 ;
dout4tmp0 =  dout4 +      ((Coeff40 * Din4s)>>8);
dout4tmp1 =  dout4tmp0 + ((Coeff41 * Din5s)>>8);
dout4tmp2 =  dout4tmp1 + ((Coeff42 * Din6s)>>8);
dout4tmp3 =  dout4tmp2 + ((Coeff43 * Din7s)>>8);
dout5 = 0 ;
dout5tmp0 =  dout5 +      ((Coeff50 * Din4s)>>8);
dout5tmp1 =  dout5tmp0 + ((Coeff51 * Din5s)>>8);
dout5tmp2 =  dout5tmp1 + ((Coeff52 * Din6s)>>8);
dout5tmp3 =  dout5tmp2 + ((Coeff53 * Din7s)>>8);
dout6 = 0 ;
dout6tmp0 =  dout6 +      ((Coeff60 * Din4s)>>8);
dout6tmp1 =  dout6tmp0 + ((Coeff61 * Din5s)>>8);
dout6tmp2 =  dout6tmp1 + ((Coeff62 * Din6s)>>8);
dout6tmp3 =  dout6tmp2 + ((Coeff63 * Din7s)>>8);
dout7 = 0 ;
dout7tmp0 =  dout7 +      ((Coeff70 * Din4s)>>8);
dout7tmp1 =  dout7tmp0 + ((Coeff71 * Din5s)>>8);
dout7tmp2 =  dout7tmp1 + ((Coeff72 * Din6s)>>8);
dout7tmp3 =  dout7tmp2 + ((Coeff73 * Din7s)>>8);


y0 = (dout0tmp3 + dout4tmp3)>>1;
y1 = (dout1tmp3 + dout5tmp3)>>1;
y2 = (dout2tmp3 + dout6tmp3)>>1;
y3 = (dout3tmp3 + dout7tmp3)>>1;

y7 = (dout0tmp3 - dout4tmp3)>>1;
y6 = (dout1tmp3 - dout5tmp3)>>1;
y5 = (dout2tmp3 - dout6tmp3)>>1;
y4 = (dout3tmp3 - dout7tmp3)>>1;


{
retVal[0] = (y0>>3);
retVal[1] = (y1>>3);
retVal[2] = (y2>>3);
retVal[3] = (y3>>3);
retVal[4] = (y4>>3);
retVal[5] = (y5>>3);
retVal[6] = (y6>>3);
retVal[7] = (y7>>3);
}
return retVal;
} 





