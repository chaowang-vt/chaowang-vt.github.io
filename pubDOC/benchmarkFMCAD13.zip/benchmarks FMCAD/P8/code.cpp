
int retVal[8];
int* compute(int X1, int X2, int X3, int X4, int X5, int X6, int X7, int X8){


int F0i1, F0i2, F0i3, F0i4;
int F1i1, F1i2, F1i3, F1i4;
int F2i1, F2i2, F2i3, F2i4;
int F3i1, F3i2, F3i3, F3i4;
int F4i1, F4i2, F4i3, F4i4;
int F5i1, F5i2;
int F6i1, F6i2;
int F7i1, F7i2;
int F8i1, F8i2;
int F9i1, F9i2, F9i3, F9i4;
int F10i1, F10i2, F10i3, F10i4;
int F11i1, F11i2, F11i3, F11i4;
int F12i1, F12i2, F12i3, F12i4;
int F13i1, F13i2, F13i3, F13i4;
int F14i1, F14i2;
int F15i1, F15i2;
int F16i1, F16i2;
int F17i1, F17i2;
int F18i1, F18i2;
int F19i1, F19i2;
int F20i1, F20i2;

int Y1;
int Y2;
int Y3;
int Y4;
int Y5;
int Y6;
int Y7;
int Y8;


F0i1 = X1 + X5;
F0i2 = X1 + X5;
F0i3 = X1 + X5;
F0i4 = X1 + X5;
F1i1 = X1 - X5;
F1i2 = X1 - X5;
F1i3 = X1 - X5;
F1i4 = X1 - X5;
F2i1 = X3 + X7;
F2i2 = X3 + X7;
F2i3 = X3 + X7;
F2i4 = X3 + X7;
F3i1 = X3 - X7;
F3i2 = X3 - X7;
F3i3 = X3 - X7;
F3i4 = X3 - X7;
F4i1 = (0*F3i1)>>6; 
F4i2 = (0*F3i2)>>6;
F4i3 = (0*F3i3)>>6; 
F4i4 = (0*F3i4)>>6; 
F5i1 = F0i1 + F2i1;
F5i2 = F0i2 + F2i2;
F6i1 = F0i3 - F2i3;
F6i2 = F0i4 - F2i4;
F7i1 = F1i1 + F4i1;
F7i2 = F1i2 + F4i2;
F8i1 = F1i3 - F4i3;
F8i2 = F1i4 - F4i4;
F9i1 = X2 + X6;
F9i2 = X2 + X6;
F9i3 = X2 + X6;
F9i4 = X2 + X6;
F10i1 = X2 - X6;
F10i2 = X2 - X6;
F10i3 = X2 - X6;
F10i4 = X2 - X6;
F11i1 = X4 + X8;
F11i2 = X4 + X8;
F11i3 = X4 + X8;
F11i4 = X4 + X8;
F12i1 = X4 - X8;
F12i2 = X4 - X8;
F12i3 = X4 - X8;
F12i4 = X4 - X8;
F13i1 = (0*F12i1)>>6; 
F13i2 = (0*F12i2)>>6;  
F13i3 = (0*F12i3)>>6;  
F13i4 = (0*F12i4)>>6; 
F14i1 = F9i1 + F11i1;
F14i2 = F9i2 + F11i2;
F15i1 = F9i3 - F11i3;
F15i2 = F9i4 - F11i4;
F16i1 = F10i1 + F13i1;
F16i2 = F10i2 + F13i2;
F17i1 = F10i3 - F13i3;
F17i2 = F10i4 - F13i4;
F18i1 = (45*F16i1)>>6; 
F18i2 = (45*F16i2)>>6; 
F19i1 = (0 * F15i1)>>6;
F19i2 = (0 * F15i2)>>6;
F20i1 = (-45*F17i1)>>6 ; 
F20i2 = (-45*F17i2)>>6 ;


Y1 = ((F5i1 + F14i1)>>1)>>2 ;
Y2 = ((F5i2 - F14i2)>>1)>>2 ;
Y5 = ((F7i1 + F18i1)>>1)>>2 ;
Y6 = ((F7i2 - F18i2)>>1)>>2 ;
Y3 = ((F6i1 + F19i1)>>1)>>2 ;
Y4 = ((F6i2 - F19i2)>>1)>>2 ;
Y7 = ((F8i1 + F20i1)>>1)>>2 ;
Y8 = ((F8i2 - F20i2)>>1)>>2 ;



{
retVal[0] = (Y1>>8);
retVal[1] = (Y2>>8);
retVal[2] = (Y3>>8);
retVal[3] = (Y4>>8);
retVal[4] = (Y5>>8);
retVal[5] = (Y6>>8);
retVal[6] = (Y7>>8);
retVal[7] = (Y8>>8);
}
return retVal;
} 


