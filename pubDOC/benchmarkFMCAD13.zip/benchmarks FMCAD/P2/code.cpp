
int retVal[1];
int* compute(int Y, int X1, int X2 )
{
int y;
int x1;
int x2;
int x1_new;
int x2_new;
int u; 

int Gain1; 
int Gain2; 
int Gain3; 
int Add1; 
int Gain4;
int Gain5;
int Gain6;
int Add2; 
int Gain7; 
int Gain8;
y = Y;
x1 = X1;
x2 = X2;
Gain1 = (31499 * x1) >> 14;
Gain2 = (-3145 * x2) >> 14;
Add1 = (Gain1 + Gain2) >> 1;
Gain3 = (432 * y) >> 14;
x1_new = ((Add1 << 1) + Gain3) >> 1;
Gain4 = (-1907 * x1) >> 14;
Gain5 = (23835 * x2) >> 14;
Add2 = Gain4 + Gain5;
Gain6 = (3345 * y) >> 14;
x2_new = (Add2 + Gain6) >> 1;
Gain7 = (24783 * x1_new) >> 14;
Gain8 = (25823 * x2_new) >> 14;
u = (Gain7 + (Gain8 << 2)) >> 2;


{
retVal[0] = u;
}

return retVal;
} 
