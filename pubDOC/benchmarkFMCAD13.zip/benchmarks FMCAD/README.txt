These benchmarks were used in the following paper:

@inproceedings{DBLP:conf/fmcad/EldibW13,
  author    = {Hassan Eldib and
               Chao Wang},
  title     = {An {SMT} based method for optimizing arithmetic computations in embedded
               software code},
  booktitle = {Formal Methods in Computer-Aided Design, {FMCAD} 2013, Portland, OR,
               USA, October 20-23, 2013},
  pages     = {129--136},
  year      = {2013},
  url       = {http://ieeexplore.ieee.org/xpl/freeabs_all.jsp?arnumber=6679401},
}


Each benchmark consists of two (2) input files, the benchmark source code and a tool configuration file:

1) code.cpp

Is the benchmark arithmetic computational source code written in C. It is optimized to either reduce the bitwidth needed to run the code or increase the input variables range avoiding flow overflow and underflow errors.

2) spec.txt

It is a text file containing different configurations for the algorithms used in our verification/synthesis tool. 

Most values should not be changed by the user.  

-signed: Value kept y.
-bv_a: Bitwidth of original code.
-bv_r: Target bitwidth of synthesized code.
-bv_e: Bitwidth of the fractional part in the original code fixed-point variables.
-q: Target bitwidth of the fractional part of the synthesized code fixed-point variables.
-astb: AST size of synthesis optimization region. 
-ifb: Value kept 0.
-shft_r: Bound on number of bits to shift in a single shift right operation.
-shft_l: Bound on number of bits to shift in a single shift left operation..
-All code input variables are listed here. Each is followed by its minimum and maximum values.
-step: Value kept 0.
-error: Value kept 0.
-accumulate: Value kept 1.
-mode: Value kept 2.
-GetErrRange: Value kept 0.
